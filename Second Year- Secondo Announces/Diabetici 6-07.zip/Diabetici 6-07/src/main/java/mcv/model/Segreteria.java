package mcv.model;

public class Segreteria extends Utente {

    public Segreteria(String codiceFiscale, String email, String ruolo, String password) {
        super(codiceFiscale, email, ruolo, password);
    }
}
